/* Final Visualization

Exploring 3D space with poseNet


*/


let video;
let poseNet;
let poses = [];
let skeletons = [];
let lwp;

function setup() {
  frameRate(30);
  createCanvas(800, 800, WEBGL);
  createEasyCam();

  video = createCapture(VIDEO);
  video.size(width, height);

  poseNet = ml5.poseNet(video, modelReady);
  poseNet.on('pose', function(results) {
    poses = results;
  });
  video.hide();
}

function modelReady() {
  select('#status').html('Model Loaded');
}



function body() {
  for (let i = 0; i < poses.length; i++) {
    for (let j = 0; j < poses[i].pose.keypoints.length; j++) {

      //Left Wrist
      let leftWrist = poses[i].pose.keypoints[9];
      if (leftWrist.score > 0.2) {
        push();
        translate(leftWrist.position.x, leftWrist.position.y);
        lwp = leftWrist.position.x;
        fill(0, 0, 255);
        noStroke();
        sphere(10);
        pop();

      }

      //Right Wrist
      let rightWrist = poses[i].pose.keypoints[10];
      if (rightWrist.score > 0.2) {
        push();
        translate(rightWrist.position.x, rightWrist.position.y);
        fill(0, 0, 255);
        noStroke();
        sphere(10);
    
        pop();



      }


      //Left Shoulder
      let leftShoulder = poses[i].pose.keypoints[5];
      if (leftShoulder.score > 0.2) {
        push();
        translate(leftShoulder.position.x, leftShoulder.position.y);
        fill(0, 0, 255);
        noStroke();
        sphere(10);
        
        pop();



      }

      //Right Shoulder
      let rightShoulder = poses[i].pose.keypoints[6];
      if (rightShoulder.score > 0.2) {
        push();
        translate(rightShoulder.position.x, rightShoulder.position.y);
        fill(0, 0, 255);
        noStroke();

        sphere(10);
        
        pop();

      }

      //L/R shoulder line
      push();
      stroke(255, 255, 255, 5);
      strokeWeight(5);
      line(leftShoulder.position.x, leftShoulder.position.y, rightShoulder.position.x, rightShoulder.position.y);
      pop();


      //Left Eye
      let leftEye = poses[i].pose.keypoints[1];
      if (leftEye.score > 0.2) {
        push();
     translate(leftEye.position.x, leftEye.position.y);
        sphere(10);
        pop();
        
      }


      //Right Eye
      let rightEye = poses[i].pose.keypoints[2];
      if (rightEye.score > 0.1) {
        push();
        translate(rightEye.position.x, rightEye.position.y);
        sphere(10);
        pop();
        
      }

      //Beak
      let nose = poses[i].pose.keypoints[0];
      if (nose.score > 0.1) {
        push();
        translate(nose.position.x, nose.position.y);
        sphere(10);
        pop();
        

      }
    }
  }
}

function draw() {
  background(0);
  strokeWeight(1);
  stroke(0);
    lights();
  for(let i=-2;i<3;i++)
    for(let j=-2;j<3;j++)
      for(let k=-2;k<3;k++){
        translate(150*i,150*j,lwp*k);
        fill(160+i*16,160+j*16,160+k*16);
        box(80);
        translate(-150*i,-150*j,-150*k);
      }
  push();
  translate(-400, -400);
  body();
  pop();
  
  
}